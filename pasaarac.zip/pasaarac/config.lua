Config = {}

Config.Time = 60 -- Dakika cinsinden
Config.Command = "dvall" -- komut ismi
Config.Announce = "tx" -- duyuru tipi "chat" veya "tx"
