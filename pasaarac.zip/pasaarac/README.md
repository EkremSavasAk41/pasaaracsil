Discord: savass41

Discord Sunucum: https://discord.gg/pasarp

![image](  ) 

![image](  )
