fx_version 'bodacious'
game 'gta5'
author 'Savass41'
lua54 "yes"

client_scripts {
    'client/client.lua',
    'client/entityiter.lua'
}

server_script 'server.lua'
shared_script 'config.lua'

